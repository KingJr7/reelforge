# DIRECTIVES — Reproduire le style « explainer 9:16 » *La Bonne Piste*
### Motion design · transitions · placements · pipeline de production en série (HTML natif)

> **But de ce fichier** : donner à un humain ou à une IA (Claude Code, Cursor, etc.) tout ce qu'il faut pour produire, à la chaîne, des vidéos verticales dont **l'animation, les transitions, les placements et la disposition** sont identiques aux deux vidéos de référence. Les couleurs et le logo sont des *tokens* modifiables ; le reste est à respecter à la lettre.
>
> **Légende de fiabilité** : 🟢 mesuré sur les vidéos · 🟡 estimé visuellement (à ajuster à l'œil) · 🔵 recommandation de production (non observé).

---

## 0. Résumé en 10 règles (à relire avant chaque vidéo)

1. Format **9:16**, conception en **576×1024 px**, export en **1080×1920 à 30 fps** (facteur 1,875). 🟢
2. Un écran = **logo fixe en haut → grosse carte image arrondie → texte centré → barre de progression en bas**. Rien d'autre. 🟢
3. **Une scène = une image** (2 à 7 s). Chaque changement de scène suit la même chorégraphie : *sortie fantôme flou (0,20 s) → entrée de la carte qui « pousse » depuis le bas (0,45 s)*. 🟢
4. Le texte est la **voix off écrite en direct** : chaque mot apparaît **à l'instant où il est prononcé**, en tombant d'environ 14 px avec un léger flou. 🟢
5. **1 mot-clé par phrase environ** (≈ 0,25 par seconde) est mis en emphase : violet dégradé, plus gros, animation « ressort » (grand → petit → dépassement → 1). 🟢
6. Les **chiffres** sont des compteurs qui montent de 0 à la valeur (≈ 1,15 s) et sont toujours mis en emphase. 🟢
7. Les lignes sont **mises en page une fois pour toutes** (tous les mots réservent leur place dès le début) : les mots « s'allument » sur place, le texte ne se re-centre jamais. 🟢
8. Chaque carte a une **légère rotation (±1–2°)** et dérive lentement pendant la scène ; l'image à l'intérieur zoome doucement. 🟡
9. **Écran final** = carte « marque » violette qui entre en « pop » avec dépassement, flash de mosaïque, logo d'en-tête qui disparaît, texte de conclusion dessous. 🟢
10. Le rendu est **déterministe** : toute l'animation est une fonction pure de `t`. Pas de timer, pas de transition CSS. 🔵 (condition pour que le rendu en série soit fiable)

---

## 1. Fiche technique des références 🟢

| | Vidéo A | Vidéo B |
|---|---|---|
| Sujet | Pourquoi les commerces au Congo sont tenus par des étrangers | Un vendeur d'arachides gagne plus qu'un fonctionnaire |
| Durée | 72,0 s | 52,0 s |
| Résolution / fps | 576×1024 / 30 | 576×1024 / 30 |
| Audio | voix off AAC (musique non analysée) | idem |
| Nb. de scènes | ≈ 19 (dont le logo final) | ≈ 15 (dont le logo final) |
| Durée moyenne d'une scène | ≈ 3,8 s (min 2 s, max 7 s) | ≈ 3,5 s |
| Débit de parole | ≈ 2,7 à 3 mots/s | idem |
| Mots-clés en emphase | ≈ 20 | ≈ 14 |

---

## 2. Anatomie de l'écran (repère 576×1024, origine en haut à gauche) 🟢

```
┌──────────────────────────────┐ y=0
│                              │
│        [ LOGO 100×64 ]       │ y=42 → 106   (centré, fixe)
│                              │
│ ┌──────────────────────────┐ │ y=138
│ │                          │ │
│ │   CARTE IMAGE 536×380    │ │ x=20 → 556, rayon ≈ 26 px
│ │   (rotation ±1–2°)       │ │
│ └──────────────────────────┘ │ y=518
│                              │
│   texte centré (3-4 lignes)  │ y≈564 → ~730   largeur utile 504 px (marges 36)
│   police 23,5 px / ligne 42  │
│                              │
│                              │   (zone vide volontaire : respiration)
│                              │
│  ▬▬▬▬▬▬▬▬░░░░░░░░░░░░░░░░░░  │ y=961, x 48 → 528, 4 px   (barre de progression)
└──────────────────────────────┘ y=1024
```

| Élément | x | y | Taille | Détails |
|---|---|---|---|---|
| Logo d'en-tête | centré | 42 | 100×64 | rayon ≈ 12 px, ne bouge jamais, disparaît à l'écran final |
| Carte image | 20 | 138 | 536×380 | `object-fit: cover`, rayon ≈ 26 px, ombre lavande décalée à droite/bas |
| Bloc texte | 36 → 540 | top ≈ 564 | 504 de large | `text-align:center`, première ligne : haut des ascendantes à y≈575 |
| Barre de progression | 48 | 961 | 480×4 | piste lavande, remplissage violet, rayon 3 |

Images sources : **3:2 paysage** (ex. 1536×1088) ; la carte les recadre en *cover*.
Pour du 1080×1920 : multiplier toutes les valeurs par **1,875** (le moteur le fait via `deviceScaleFactor`, ne rien recalculer à la main).

---

## 3. Tokens de design (seule zone à changer pour une autre marque)

| Token | Valeur de référence | Rôle |
|---|---|---|
| `--bg-top` / `--bg-bottom` | `#F6F2FF` → `#FFFFFF` | fond (dégradé vertical, lavande en haut) |
| `--grid` | `rgba(124,58,237,.055)` | quadrillage 28 px, masqué en haut et en bas |
| `--ink` | `#11101C` | texte courant |
| `--accent-a` / `--accent-b` | `#7C3AED` → `#A78BFA` | dégradé des mots-clés (gauche → droite) |
| `--shadow` | `rgba(139,92,246,.28)` | ombre de la carte et du logo |
| `--track` / `--fill` | `rgba(124,58,237,.14)` / `#7C3AED` | barre de progression |
| Police | **Poppins** — 600 (texte), 800 (mots-clés) | à héberger en local (jamais d'appel Google Fonts pendant le rendu) |
| Taille texte | 23,5 px, interligne 42 px, `letter-spacing:-.3px` | 🟢 calé sur la largeur réelle des lignes de A |
| Emphase | ×1,25, poids 800, `vertical-align:-.12em` | le mot-clé « descend » un peu sous la ligne de base |

Changer de marque = changer ces tokens + le logo + l'image de la carte finale. **Ne pas** toucher aux positions ni aux timings.

---

## 4. Spécification des animations

Toutes les durées sont en secondes, `t` = temps global de la vidéo, `T` = début d'une scène.

### 4.1 Easings utilisés (cubic-bezier, identiques au CSS)

| Nom | Courbe | Usage |
|---|---|---|
| `outExpo` | `(.16, 1, .3, 1)` | entrée de la carte, montée du logo final |
| `outCubic` | `(.215, .61, .355, 1)` | chute des mots, compteurs |
| `outBack` | `(.34, 1.56, .64, 1)` | « pop » du logo final |
| `inCubic` | `(.32, 0, .67, 0)` | sortie fantôme |
| `inOut` | `(.65, 0, .35, 1)` | dérive lente de la pose de la carte |
| `sine` | `(.37, 0, .63, 1)` | interpolation entre images-clés du mot-clé |

### 4.2 Carte image — entrée 🟢 (0,45 s, `outExpo`)

| Propriété | De → À |
|---|---|
| `scaleY` (origine **bas** de la carte) | 0,20 → 1 |
| `translateY` | +28 px → 0 |
| rotation additionnelle | −3° (× signe de la pose) → 0 |
| opacité | 0 → 1 sur les 0,08 premières secondes |

Effet recherché : la carte semble « surgir du bas » en s'étirant (squash & stretch), le haut de la carte monte de ≈ y 436 à y 138 pendant que le bas reste quasi fixe. À mi-entrée, la carte est une bande plate d'environ 100 px de haut.

### 4.3 Carte image — sortie « fantôme » 🟢 (0,20 s, `inCubic`, juste avant `T`)

| Propriété | De → À |
|---|---|
| opacité | 1 → ≈ 0,03 |
| flou | 0 → 8 px |
| échelle | 1 → 1,03 |
| `translateY` | 0 → −8 px |
| texte (tout le bloc) | opacité 1 → 0, flou 0 → 6 px (en même temps) |

La sortie finit **exactement** à `T` ; l'entrée de la scène suivante démarre à `T` (pas de trou, pas de chevauchement visible).

### 4.4 Carte image — pose et dérive pendant la scène 🟡

Chaque scène reçoit une pose de départ et d'arrivée, interpolées avec `inOut` sur toute la durée de la scène :

| Paramètre | Départ → Arrivée |
|---|---|
| rotation | `r0` ∈ ±[0,9°; 2,2°] → `−0,55·r0` (signe alterné d'une scène à l'autre) |
| décalage horizontal | ±(4–10 px) → ∓3 px |
| échelle de la carte | 0,985 → 1,015 |
| zoom de l'image dans la carte | 1,00 → 1,06 + micro-pan ±10 px |

Règle : **alterner le sens de rotation d'une scène à l'autre** pour que le montage « respire ». Le moteur le fait automatiquement (`autoPose`), on peut forcer une pose avec `"pose": {...}` dans la scène.

### 4.5 Mot normal 🟢 (0,20 s, `outCubic`)

Déclenché à l'instant exact où le mot est prononcé (`word.t`).

| Propriété | De → À |
|---|---|
| `translateY` | −14 px (arrive **d'en haut**) → 0 |
| flou | 4 px → 0 |
| rotation | −3° → 0 |
| opacité | 0 → 1 (atteint 1 à 40 % de la durée) |

Le mot est gris/translucide pendant sa chute puis devient noir encre.

### 4.6 Mot-clé (emphase) 🟢 (0,60 s au total, interpolation `sine` entre images-clés)

| Temps rel. | Échelle | Opacité | Flou | Rotation |
|---|---|---|---|---|
| 0,00 | 2,40 | 0 | 12 px | −5° |
| 0,03 | 2,30 | 0,55 | 8 | −4° |
| 0,07 | 2,10 | 0,60 | 6 | −3° |
| 0,10 | 1,30 | 0,85 | 2 | −1° |
| 0,13 | **0,62** | 1 | 0 | 0 |
| 0,20 | **0,52** (creux) | 1 | 0 | 0 |
| 0,27 | 0,85 | 1 | 0 | 0 |
| 0,30 | 1,10 | 1 | 0 | 0 |
| 0,35 | **1,20** (dépassement) | 1 | 0 | 0 |
| 0,43 | 1,05 | 1 | 0 | 0 |
| 0,50 | 0,97 | 1 | 0 | 0 |
| 0,60 | **1,00** | 1 | 0 | 0 |

Habillage : dégradé violet `accent-a → accent-b` à ~100°, poids 800, ×1,25. Sous le mot, une **lueur lavande floue** (ellipse `rgba(167,139,250,.38)`, flou 6 px, 14 px de haut, 6 px sous la ligne de base) dont l'opacité monte de 0 à 1 entre 0,25 s et 0,55 s.
Le mot-clé peut être isolé sur sa propre ligne (c'est la mise en page qui décide, pas l'animation).

### 4.7 Compteur de chiffres 🟢

- Mot-clé comme ci-dessus, mais le texte affiché passe de 0 à la valeur finale en **1,15 s** (`outCubic`).
- Séparateur de milliers : espace fine insécable (`120 000`).
- Suffixe (`%`) attaché au nombre par une espace insécable.
- **La largeur du mot est figée sur sa valeur finale** (sinon la ligne saute pendant le comptage).
- Exemples dans les références : `65 % → 90 %`, `119 000 → 120 000`, `360 000`.

### 4.8 Barre de progression 🟢

Largeur = `t / durée_totale`, **linéaire**, sans easing, du début à la fin (100 % sur l'écran final).

### 4.9 Écran final « marque » 🟢 / 🟡

| Moment | Action |
|---|---|
| `T−0,12 → T+0,03` | logo d'en-tête : opacité 1 → 0 |
| `T−0,04 → T+0,16` | **flash de mosaïque** : calque damier gris-lavande 24 px (blend `multiply`), opacité 0,9 → 0 |
| `T → T+0,50` | carte marque : échelle ×1,18 → 1 (`outBack`), rotation −6° → pose, `translateY` 30 → 0 (`outExpo`), opacité 0 → 1 sur 0,12 s |
| ensuite | dérive lente comme les autres cartes ; texte final animé comme d'habitude |

La carte marque = rectangle violet `#6400B0` aux mêmes dimensions que la carte photo, logo en `contain` au centre. Pas de sortie : la vidéo se termine dessus, barre à 100 %.

---

## 5. Chorégraphie d'un changement de scène (chronologie à la milliseconde)

```
T-0.20 ──────── T ────────────────────────────────── T+0.45
  │ sortie fantôme │ ENTRÉE carte (squash → 1, outExpo)     │
  │ carte+texte    │                                         │
  │ blur/fondu     │      T+0.13 : 1er mot de la scène       │
  │                │      (la voix démarre ≈ ici)            │
```

- Décaler le début de scène : `T = (instant du 1er mot) − 0,13 s`. `build.mjs` le fait seul.
- La fin d'une scène = le début de la suivante.
- Pas de crossfade, pas de glissement latéral, pas de zoom caméra : **uniquement** ce couple sortie fantôme / entrée squash.

---

## 6. Règles d'écriture et de montage

### 6.1 Structure narrative (observée dans A et B)

1. **Hook (0–6 s)** : question ou chiffre choc, mot-clé dès les 2 premières secondes (`90 %`, `vendeur d'arachides`).
2. **Renversement / thèse (6–15 s)** : « la réponse est simple », « ça peut faire rire, mais réfléchis bien ».
3. **Développement par contrastes** : « eux / nous », « statut / stratégie », « fonctionnaire / vendeur ». Une idée par scène.
4. **Preuve chiffrée** si possible (compteurs).
5. **Chute / appel à l'action** sur l'écran final, avec la marque : phrase de conclusion + mot-clé final (`opportunités`, `refusons`).
6. **Boucle** (vidéo A) : réutiliser l'image du début dans les dernières scènes.

### 6.2 Découpage en scènes

| Paramètre | Valeur |
|---|---|
| Durée d'une scène | 2 à 7 s (idéal 3–4 s) |
| Mots par scène | 6 à 22 |
| Lignes de texte à l'écran | 1 à 4 (au-delà : couper la scène) |
| Coupure | sur une virgule, un point, ou un changement d'idée — jamais au milieu d'un groupe nominal |
| Mots-clés | 1–2 par scène, jamais 2 consécutifs ; toujours : chiffres, verbes forts, mots émotionnels, mot de chute |

### 6.3 Transcriptions de référence (lecture visuelle, approximatives)

**Vidéo A** — 0 s : « pourquoi **90 %** des boutiques et alimentations au congo sont-elles tenues par des étrangers plutôt que par les congolais **eux-mêmes** ? » · 6,6 s : « la réponse est **simple.** » · 8,8 s : « notre **ego,** notre recherche de prestige et notre volonté de gagner beaucoup en une seule fois. » · 13,6 s : « les étrangers qui développent leur business au congo n'ont rien de **magique.** » · 16,7 s : « ils ont simplement compris que le commerce, ce n'est pas une question de prestige mais de **stratégie.** » · 21,6 s : « nous, les congolais, avons parfois **honte** de commencer petit. » · 25,6 s : « on veut être assis dans un bureau **chic,** » · 27,6 s : « et donner **l'impression** d'avoir réussi. » · 30,5 s : « pendant ce temps, d'autres construisent leur **richesse** en vendant des … » · 33,6 s : « en tenant des boutiques et en **fidélisant** leurs clients. » · 36,5 s : « au marché poto-poto, certains commerçants savent **négocier,** accepter de gagner une marge **raisonnable** et faire revenir leurs clients. » · 42,8 s : « les congolais préfèrent vendre **trois ou quatre** … pour chercher à gagner beaucoup en un coup, quitte à **perdre** le client. » · 50 s : « le commerce, ce n'est pas gagner beaucoup sur une **seule** vente, c'est faire **revenir** le client encore et encore. » · 54,8 s : « tant que nous préférerons **paraître** riches plutôt que construire une véritable **richesse,** » · 59,8 s : « nous continuerons à laisser des **opportunités** … » · 62,5 s : « la question n'est pas de savoir pourquoi les étrangers **réussissent,** » · 65,5 s (logo) : « mais pourquoi nous **refusons** parfois de faire ce qu'il faut pour réussir nous-mêmes. »

**Vidéo B** — 0 s : « tu savais qu'un vendeur **d'arachides** au congo pouvait gagner plus qu'un fonctionnaire ? » · 3,7 s : « ça peut faire **rire,** mais réfléchis bien. » · 6,7 s : « un fonctionnaire gagne en moyenne **120 000** francs cfa par mois, » · 9,6 s : « alors qu'un vendeur d'arachides peut se faire entre 12 000 et 13 000 francs cfa par **jour.** » · 14,8 s : « fais le **calcul.** » · 15,7 s : « 12 000 francs cfa multiplié par 30 jours, ça fait **360 000** francs cfa » · 20,7 s : « et pourtant, nous les congolais, nous avons tendance à **mépriser** les … tout en nous plaignant du manque **d'opportunités.** » · 26,8 s : « mais les opportunités sont …, il suffit d'ouvrir les **yeux.** » · 30,7 s : « si dans ton quartier, tu as du mal à trouver du **charbon** pour cuisiner, sache que tes voisins ont probablement le même **problème.** pourquoi ne pas en **vendre ?** » · 38 s : « le business, tu identifies un problème, tu proposes une **solution,** et tu gagnes de l'argent en **aidant** … » · 44 s : « arrêtons de **mépriser** les petits métiers. » · 46,5 s (logo) : « parfois, c'est justement là que se trouvent les plus grandes **opportunités.** »

---

## 7. Direction des images (prompt type pour le générateur d'images)

- Format **3:2 paysage**, ≥ 1536×1024, photoréaliste, façon photo documentaire.
- Lumière naturelle chaude (fin d'après-midi), profondeur de champ moyenne, scène de **vie quotidienne**, sujets au centre-droit, **un seul sujet clair par image**.
- **Touche de violet récurrente** (cravate, chemise, classeur, flacons, tissu) pour répondre à la marque.
- Pas de texte lisible dans l'image, pas de logo tiers, pas de bordure.
- Une image **par scène** ; réserver 1–2 images « fortes » pour le hook et pour la boucle de fin.

Gabarit de prompt : `Photo réaliste, scène de [lieu/situation], [sujet et action], lumière dorée naturelle, détails du quotidien, accent de couleur violette sur [objet/vêtement], composition horizontale 3:2, sujet principal lisible, sans texte.`

---

## 8. Pipeline de production en série

### 8.1 Arborescence

```
motion-kit/
├── engine/                 # index.html + engine.js  (ne pas toucher entre deux vidéos)
├── render.mjs              # HTML -> frames -> MP4
├── scripts/build.mjs       # script.json + words.json -> video.json
├── assets/fonts/           # Poppins-SemiBold.ttf, Poppins-ExtraBold.ttf
└── videos/
    └── 001-mon-sujet/
        ├── script.json     # texte découpé en scènes + chemins d'images
        ├── voice.mp3       # voix off (TTS ou enregistrée)
        ├── words.json      # généré par Whisper
        ├── img/s01.jpg …   # une image par scène
        └── video.json      # généré
```

### 8.2 Étapes (≈ 5 commandes par vidéo)

```bash
# 0. installation (une fois) — Node ≥ 20, FFmpeg
npm i playwright && npx playwright install chromium

# 1. écrire script.json (voir §9.5), générer les images, générer la voix

# 2. timestamps mot par mot (Python, une fois : pip install faster-whisper)
python3 - <<'PY'
import json
from faster_whisper import WhisperModel
m = WhisperModel("small", compute_type="int8")
segs, _ = m.transcribe("videos/001-mon-sujet/voice.mp3", language="fr", word_timestamps=True)
words = [{"word": w.word.strip(), "start": w.start, "end": w.end} for s in segs for w in s.words]
json.dump(words, open("videos/001-mon-sujet/words.json", "w"), ensure_ascii=False)
PY

# 3. assembler
node scripts/build.mjs videos/001-mon-sujet/script.json videos/001-mon-sujet/words.json videos/001-mon-sujet/video.json

# 4. contrôle visuel rapide (PNG aux instants clés)
node render.mjs videos/001-mon-sujet/video.json --stills 0.5,3,6.2 --scale 1

# 5. rendu final 1080×1920
node render.mjs videos/001-mon-sujet/video.json out/001.mp4 --scale 1.875
```

> `build.mjs` accepte `-` à la place de `words.json` pour une version **estimée sans voix** (165 mots/min, option `--wpm`). Pratique pour valider la mise en page avant d'enregistrer.

### 8.3 Production en lot

```bash
for d in videos/*/; do
  n=$(basename "$d")
  node scripts/build.mjs "$d/script.json" "$d/words.json" "$d/video.json" &&
  node render.mjs "$d/video.json" "out/$n.mp4" --scale 1.875
done
```
Parallélisation : lancer plusieurs `render.mjs` sur des vidéos différentes (1 processus par cœur), ou découper une vidéo avec `--from/--to` puis concaténer avec FFmpeg.

### 8.4 Ce que doit faire une IA qui exécute ce fichier

1. Ne **jamais** modifier `engine/` pour « améliorer » le style : seuls les tokens CSS (`:root`) et `video.json` changent.
2. Générer `script.json` en respectant §6 (découpage, emphase, rythme).
3. Après `--stills`, comparer visuellement aux points de contrôle du §11 avant le rendu complet.
4. Si une ligne dépasse 4 lignes de texte, **couper la scène** (ne pas réduire la police).

---

## 9. Code de référence (testé : rendu d'images fixes et d'un MP4)

### 9.1 `engine/index.html` — mise en page et tokens

```html
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<base href="../"><!-- toutes les ressources (images, polices, audio) sont relatives à la RACINE du projet -->
<title>Motion Template — Brand Explainer 9:16</title>
<meta name="viewport" content="width=576,height=1024">
<style>
/* ============ 1. DESIGN TOKENS (seule zone à changer pour une autre marque) ============ */
:root{
  --W:576px; --H:1024px;
  --bg-top:#F6F2FF; --bg-bottom:#FFFFFF;           /* fond lavande -> blanc */
  --grid:rgba(124,58,237,.055);                    /* quadrillage */
  --ink:#11101C;                                   /* texte courant */
  --accent-a:#7C3AED; --accent-b:#A78BFA;          /* dégradé mot-clé */
  --shadow:rgba(139,92,246,.28);                   /* ombre carte (lavande) */
  --track:rgba(124,58,237,.14); --fill:#7C3AED;    /* barre de progression */
  --card-x:20px; --card-y:138px; --card-w:536px; --card-h:380px; --card-r:26px;
  --text-top:564px; --text-pad:36px; --fs:23.5px; --lh:42px;
  --logo-y:42px; --logo-w:100px; --logo-h:64px;
  --bar-x:48px; --bar-y:961px; --bar-w:480px; --bar-h:4px;
}
@font-face{font-family:"Poppins";font-weight:600;src:url("assets/fonts/Poppins-SemiBold.ttf")}
@font-face{font-family:"Poppins";font-weight:800;src:url("assets/fonts/Poppins-ExtraBold.ttf")}

/* ============ 2. STAGE ============ */
*{box-sizing:border-box;margin:0;padding:0}
html,body{width:var(--W);height:var(--H);overflow:hidden;background:#fff}
#stage{position:relative;width:var(--W);height:var(--H);overflow:hidden;
  background:linear-gradient(180deg,var(--bg-top) 0%,#FBF9FF 45%,var(--bg-bottom) 100%);
  font-family:"Poppins",system-ui,sans-serif;color:var(--ink)}
#grid{position:absolute;inset:0;
  background-image:linear-gradient(var(--grid) 1px,transparent 1px),linear-gradient(90deg,var(--grid) 1px,transparent 1px);
  background-size:28px 28px;
  -webkit-mask-image:linear-gradient(180deg,transparent 0%,#000 55%,#000 92%,transparent 100%);
          mask-image:linear-gradient(180deg,transparent 0%,#000 55%,#000 92%,transparent 100%)}
#logo{position:absolute;left:50%;top:var(--logo-y);width:var(--logo-w);height:var(--logo-h);
  margin-left:calc(var(--logo-w) / -2);border-radius:12px;object-fit:cover;
  box-shadow:0 6px 16px -6px var(--shadow)}

/* ============ 3. CARTE IMAGE ============ */
.card{position:absolute;left:var(--card-x);top:var(--card-y);width:var(--card-w);height:var(--card-h);
  transform-origin:50% 100%;will-change:transform,opacity,filter;opacity:0}
.card .shadow{position:absolute;inset:0;border-radius:var(--card-r);
  box-shadow:12px 10px 28px -6px var(--shadow),0 18px 36px -18px var(--shadow);background:#fff}
.card .clip{position:absolute;inset:0;border-radius:var(--card-r);overflow:hidden;background:#ddd}
.card img{position:absolute;left:0;top:0;width:100%;height:100%;object-fit:cover;transform-origin:50% 50%}
.card.brand .clip{background:#6400B0}
.card.brand img{object-fit:contain}

/* ============ 4. TEXTE ============ */
.text{position:absolute;left:var(--text-pad);right:var(--text-pad);top:var(--text-top);
  text-align:center;font-weight:600;font-size:var(--fs);line-height:var(--lh);letter-spacing:-.3px;opacity:1}
.w{display:inline-block;white-space:pre;opacity:0;will-change:transform,opacity,filter;vertical-align:baseline}
.w.em{font-weight:800;font-size:1.25em;line-height:1;position:relative;vertical-align:-.12em;
  background:linear-gradient(100deg,var(--accent-a) 10%,var(--accent-b) 95%);
  -webkit-background-clip:text;background-clip:text;color:transparent;-webkit-text-fill-color:transparent;
  padding:0 .06em}
.w.em::after{content:"";position:absolute;left:4%;right:2%;bottom:-6px;height:14px;border-radius:50%;
  background:rgba(167,139,250,.38);filter:blur(6px);z-index:-1;opacity:var(--glow,0)}
.sp{display:inline-block;width:.28em}

/* ============ 5. PROGRESSION + MOSAÏQUE ============ */
#bar{position:absolute;left:var(--bar-x);top:var(--bar-y);width:var(--bar-w);height:var(--bar-h);
  border-radius:3px;background:var(--track);overflow:hidden}
#bar i{display:block;height:100%;width:0;border-radius:3px;background:linear-gradient(90deg,var(--fill),#8B5CF6)}
#mosaic{position:absolute;inset:0;opacity:0;pointer-events:none;mix-blend-mode:multiply;
  background-image:linear-gradient(#0000 0 0),
   repeating-conic-gradient(#d9d3e6 0 25%,#f3f0f9 0 50%);background-size:100% 100%,24px 24px}
</style>
</head>
<body>
<div id="stage">
  <div id="grid"></div>
  <img id="logo" alt="">
  <div id="cards"></div>
  <div id="texts"></div>
  <div id="bar"><i></i></div>
  <div id="mosaic"></div>
</div>
<script src="engine/engine.js"></script>
</body>
</html>
```

### 9.2 `engine/engine.js` — moteur d'animation pur

```javascript
/* =====================================================================
 *  MOTION ENGINE — pur, déterministe : render(t) ne dépend que de t.
 *  Aucun setTimeout / requestAnimationFrame / CSS animation => capture
 *  frame-par-frame parfaite (Puppeteer / Playwright / HyperFrames / Remotion).
 * ===================================================================== */
(() => {
"use strict";

/* ---------- 0. Utilitaires mathématiques ---------- */
const clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x));
const lerp  = (a, b, t) => a + (b - a) * t;

// cubic-bezier identique au CSS (Newton + bissection)
function bezier(x1, y1, x2, y2) {
  const cx = 3 * x1, bx = 3 * (x2 - x1) - cx, ax = 1 - cx - bx;
  const cy = 3 * y1, by = 3 * (y2 - y1) - cy, ay = 1 - cy - by;
  const X = t => ((ax * t + bx) * t + cx) * t, Y = t => ((ay * t + by) * t + cy) * t;
  const dX = t => (3 * ax * t + 2 * bx) * t + cx;
  return x => {
    if (x <= 0) return 0; if (x >= 1) return 1;
    let t = x;
    for (let i = 0; i < 8; i++) { const e = X(t) - x; if (Math.abs(e) < 1e-6) return Y(t); const d = dX(t); if (Math.abs(d) < 1e-6) break; t -= e / d; }
    let lo = 0, hi = 1; t = x;
    while (lo < hi) { const v = X(t); if (Math.abs(v - x) < 1e-6) break; v < x ? lo = t : hi = t; t = (lo + hi) / 2; if (hi - lo < 1e-7) break; }
    return Y(t);
  };
}
const ease = {
  outExpo : bezier(.16, 1, .3, 1),      // entrée de carte (rapide puis très doux)
  outCubic: bezier(.215, .61, .355, 1), // chute des mots
  outBack : bezier(.34, 1.56, .64, 1),  // pop du logo final
  inCubic : bezier(.32, 0, .67, 0),     // sortie de scène
  inOut   : bezier(.65, 0, .35, 1),     // dérive lente de la carte
  sine    : bezier(.37, 0, .63, 1)
};

// interpolation par images-clés : kf(t,[[t0,v0..],[t1,v1..],...]) -> tableau de valeurs
function keyframes(t, frames, easing = ease.sine) {
  if (t <= frames[0][0]) return frames[0].slice(1);
  const last = frames[frames.length - 1];
  if (t >= last[0]) return last.slice(1);
  for (let i = 0; i < frames.length - 1; i++) {
    const a = frames[i], b = frames[i + 1];
    if (t >= a[0] && t <= b[0]) {
      const p = easing((t - a[0]) / (b[0] - a[0]));
      return a.slice(1).map((v, k) => lerp(v, b[k + 1], p));
    }
  }
}

/* ---------- 1. Constantes d'animation (mesurées sur les vidéos de référence) ---------- */
const C = {
  CARD_ENTER : 0.45,   // s — la carte « pousse » depuis le bas (squash -> 1)
  CARD_EXIT  : 0.20,   // s — fantôme flou + fondu
  CARD_SQUASH: 0.20,   // scaleY de départ
  CARD_RISE  : 28,     // px de translation de départ (vers le bas)
  WORD_DUR   : 0.20,   // s — chute d'un mot normal
  WORD_DROP  : -14,    // px — le mot arrive d'en haut
  WORD_BLUR  : 4,      // px
  COUNT_DUR  : 1.15,   // s — compteur 0 -> valeur
  ZOOM_END   : 1.06,   // zoom lent de l'image dans la carte
  // mot d'emphase : [t(s), scale, opacité, flou(px), rotation(deg)]
  EM: [
    [0.00, 2.40, 0.00, 12, -5], [0.03, 2.30, 0.55, 8, -4], [0.07, 2.10, 0.60, 6, -3],
    [0.10, 1.30, 0.85,  2, -1], [0.13, 0.62, 1.00, 0,  0], [0.20, 0.52, 1.00, 0, 0],
    [0.27, 0.85, 1.00,  0,  0], [0.30, 1.10, 1.00, 0,  0], [0.35, 1.20, 1.00, 0, 0],
    [0.43, 1.05, 1.00,  0,  0], [0.50, 0.97, 1.00, 0,  0], [0.60, 1.00, 1.00, 0, 0]
  ]
};
const EM_LEN = C.EM[C.EM.length - 1][0];

/* ---------- 2. Construction du DOM ---------- */
let V = null, S = [];          // vidéo + scènes construites
const $ = id => document.getElementById(id);
const fmt = (n, sep = "\u202F") => String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, sep);

// pose « caméra » de la carte : rotation / décalage / échelle, avec dérive pendant la scène
function autoPose(i) {
  const sgn = i % 2 ? 1 : -1;
  const r0 = sgn * (0.9 + ((i * 37) % 10) / 10 * 1.3);       // ±0.9° .. ±2.2°
  return { rot0: r0, rot1: -r0 * 0.55, dx0: sgn * (4 + (i * 13) % 7), dx1: -sgn * 3, s0: 0.985, s1: 1.015,
           panX: sgn * 10, panY: ((i * 5) % 3 - 1) * 4 };
}

async function load(video) {
  V = video;
  const st = Object.assign({}, V.style || {});
  for (const k in st) document.documentElement.style.setProperty(k.startsWith("--") ? k : "--" + k, st[k]);
  $("logo").src = V.logo || ""; 
  $("cards").innerHTML = ""; $("texts").innerHTML = ""; S = [];

  V.scenes.forEach((sc, i) => {
    const brand = sc.type === "brand";
    const card = document.createElement("div");
    card.className = "card" + (brand ? " brand" : "");
    card.innerHTML = `<div class="shadow"></div><div class="clip"><img src="${sc.image}" alt=""></div>`;
    $("cards").appendChild(card);

    const box = document.createElement("div");
    box.className = "text"; box.style.visibility = "hidden";
    const words = (sc.words || []).map((w, k) => {
      const el = document.createElement("span");
      el.className = "w" + (w.em ? " em" : "");
      el.textContent = w.count ? fmt(w.count.to) + (w.count.suffix || "") : w.w;
      box.appendChild(el);
      if (k < sc.words.length - 1) box.appendChild(document.createTextNode(" "));
      return { el, w };
    });
    $("texts").appendChild(box);
    S.push({ sc, i, card, img: card.querySelector("img"), box, words, pose: Object.assign(autoPose(i), sc.pose || {}) });
  });

  // fige la largeur finale des compteurs pour éviter tout « saut » de ligne
  S.forEach(s => s.words.forEach(o => { if (o.w.count) o.el.style.width = o.el.getBoundingClientRect().width + "px"; }));
  await document.fonts.ready;
  await Promise.all([...document.images].map(im => im.decode ? im.decode().catch(() => {}) : 0));
  window.__ready = true;
}

/* ---------- 3. Rendu d'un instant t (secondes) ---------- */
function render(t) {
  const D = V.duration;

  // 3.1 barre de progression (linéaire sur toute la durée)
  $("bar").firstElementChild.style.width = (clamp(t / D) * 100) + "%";

  // 3.2 logo d'en-tête : fixe, disparaît à l'arrivée de l'écran final
  const brandScene = S.find(s => s.sc.type === "brand");
  let logoOp = 1;
  if (brandScene) logoOp = 1 - clamp((t - (brandScene.sc.start - 0.12)) / 0.15);
  $("logo").style.opacity = logoOp;

  let mosaic = 0;

  S.forEach((s, idx) => {
    const { sc, card, img, box, pose } = s;
    const start = sc.start, end = sc.end, dur = end - start;
    const isLast = idx === S.length - 1, brand = sc.type === "brand";
    const visible = t >= start && (t < end || isLast);
    card.style.opacity = 0; box.style.visibility = "hidden";
    if (!visible) { card.style.visibility = "hidden"; return; }
    card.style.visibility = "visible"; box.style.visibility = "visible";

    // --- phases ---
    const u    = clamp((t - start) / dur);                                  // 0..1 sur la scène
    const pIn  = clamp((t - start) / (brand ? 0.5 : C.CARD_ENTER));
    const pOut = isLast ? 0 : clamp((t - (end - C.CARD_EXIT)) / C.CARD_EXIT);
    const drift = ease.inOut(u);

    // --- carte : pose de base (dérive lente) ---
    let rot = lerp(pose.rot0, pose.rot1, drift);
    let dx  = lerp(pose.dx0, pose.dx1, drift);
    let sx  = lerp(pose.s0, pose.s1, drift), sy = sx;
    let ty = 0, op = 1, blur = 0;

    // --- entrée ---
    if (brand) {                       // écran logo : « pop » avec dépassement + mosaïque
      const e = ease.outBack(pIn);
      sx = sy = lerp(1.18, 1, e) * sx; rot = lerp(-6, rot, e); ty = lerp(30, 0, ease.outExpo(pIn));
      op = clamp(pIn / 0.25);
      mosaic = Math.max(mosaic, 0.9 * (1 - clamp((t - (start - 0.04)) / 0.2)) * (t >= start - 0.04 ? 1 : 0));
    } else {                           // carte photo : squash vertical depuis le bas
      const e = ease.outExpo(pIn);
      sy *= lerp(C.CARD_SQUASH, 1, e);
      ty = lerp(C.CARD_RISE, 0, e);
      rot += lerp(-3 * Math.sign(pose.rot0 || 1), 0, e);
      op = clamp(pIn / 0.18);
    }
    // --- sortie : fantôme flou ---
    if (pOut > 0) {
      const q = ease.inCubic(pOut);
      op *= 1 - q * 0.97; blur = 8 * q; sx *= 1 + 0.03 * q; sy *= 1 + 0.03 * q; ty -= 8 * q;
    }
    card.style.opacity = op;
    card.style.filter = blur ? `blur(${blur.toFixed(2)}px)` : "none";
    card.style.transform = `translate(${dx.toFixed(2)}px,${ty.toFixed(2)}px) rotate(${rot.toFixed(3)}deg) scale(${sx.toFixed(4)},${sy.toFixed(4)})`;

    // --- image à l'intérieur : lent zoom + micro-pan (« Ken Burns ») ---
    if (!brand) img.style.transform = `translate(${(pose.panX * u).toFixed(2)}px,${(pose.panY * u).toFixed(2)}px) scale(${lerp(1, C.ZOOM_END, u).toFixed(4)})`;

    // --- texte : mots apparaissent à la voix ---
    const textOut = pOut > 0 ? ease.inCubic(pOut) : 0;
    box.style.opacity = 1 - textOut; box.style.filter = textOut ? `blur(${(6 * textOut).toFixed(2)}px)` : "none";
    s.words.forEach(({ el, w }) => {
      const lt = t - w.t;
      if (lt < 0) { el.style.opacity = 0; return; }
      if (w.em) {
        const [sc2, o, b, r] = keyframes(lt, C.EM);
        el.style.opacity = o; el.style.filter = b > 0.05 ? `blur(${b.toFixed(2)}px)` : "none";
        el.style.transform = `rotate(${r.toFixed(2)}deg) scale(${sc2.toFixed(3)})`;
        el.style.setProperty("--glow", clamp((lt - 0.25) / 0.3).toFixed(3));
      } else {
        const p = clamp(lt / C.WORD_DUR), e = ease.outCubic(p);
        el.style.opacity = clamp(p * 2.4);
        el.style.filter = p < 1 ? `blur(${(C.WORD_BLUR * (1 - e)).toFixed(2)}px)` : "none";
        el.style.transform = `translateY(${(C.WORD_DROP * (1 - e)).toFixed(2)}px) rotate(${(-3 * (1 - e)).toFixed(2)}deg)`;
      }
      if (w.count) {
        const v = lerp(w.count.from || 0, w.count.to, ease.outCubic(clamp(lt / C.COUNT_DUR)));
        el.textContent = fmt(v) + (w.count.suffix || "");
      }
    });
  });

  $("mosaic").style.opacity = mosaic;
}

window.loadVideo = load;
window.__render = render;
window.__EASE = ease; window.__C = C;
})();
```

### 9.3 `render.mjs` — capture déterministe + encodage

```javascript
#!/usr/bin/env node
/* Rendu déterministe : HTML -> frames (Playwright) -> MP4 (FFmpeg).
 *   node render.mjs video.json out/video.mp4 [--scale 1.875] [--fps 30] [--from 0] [--to 99999]
 *   node render.mjs video.json --stills 0.5,3,6.2           (PNG de contrôle dans out/stills/)
 */
import { chromium } from "playwright";
import { spawn } from "node:child_process";
import { readFileSync, mkdirSync, existsSync } from "node:fs";
import { resolve, dirname } from "node:path";
import { pathToFileURL } from "node:url";

const args = process.argv.slice(2);
const flag = (n, d) => { const i = args.indexOf("--" + n); return i < 0 ? d : args[i + 1]; };
const [videoPath, outPath] = args.filter(a => !a.startsWith("--") && !/^[\d.,]+$/.test(a));
const scale = parseFloat(flag("scale", "1.875"));         // 576*1.875 = 1080 ; 1024*1.875 = 1920
const video = JSON.parse(readFileSync(videoPath, "utf8"));
const fps   = parseInt(flag("fps", video.fps || 30), 10);
const total = Math.round(video.duration * fps);
const from  = parseInt(flag("from", 0), 10), to = Math.min(total, parseInt(flag("to", total), 10));
const stills = flag("stills", null);

const browser = await chromium.launch({ args: ["--force-color-profile=srgb", "--font-render-hinting=none", "--disable-lcd-text"] });
const page = await browser.newPage({ viewport: { width: 576, height: 1024 }, deviceScaleFactor: scale });
await page.goto(pathToFileURL(resolve(dirname(new URL(import.meta.url).pathname), "engine/index.html")).href);
await page.evaluate(v => window.loadVideo(v), video);
await page.waitForFunction(() => window.__ready === true);

if (stills) {
  mkdirSync("out/stills", { recursive: true });
  for (const s of stills.split(",")) {
    await page.evaluate(t => window.__render(t), parseFloat(s));
    await page.screenshot({ path: `out/stills/t_${parseFloat(s).toFixed(2)}.png` });
  }
  await browser.close(); process.exit(0);
}

mkdirSync(dirname(outPath), { recursive: true });
const ff = spawn("ffmpeg", ["-y", "-loglevel", "error",
  "-f", "image2pipe", "-framerate", String(fps), "-c:v", "mjpeg", "-i", "-",
  ...(video.audio ? ["-i", resolve(dirname(videoPath), video.audio)] : []),
  "-c:v", "libx264", "-preset", "medium", "-crf", "17", "-pix_fmt", "yuv420p", "-r", String(fps),
  ...(video.audio ? ["-c:a", "aac", "-b:a", "192k", "-shortest"] : []),
  "-movflags", "+faststart", outPath], { stdio: ["pipe", "inherit", "inherit"] });

for (let f = from; f < to; f++) {
  await page.evaluate(t => window.__render(t), f / fps);
  const buf = await page.screenshot({ type: "jpeg", quality: 95 });
  if (!ff.stdin.write(buf)) await new Promise(r => ff.stdin.once("drain", r));
  if (f % fps === 0) process.stdout.write(`\r${f}/${total} frames`);
}
ff.stdin.end();
await new Promise(r => ff.on("close", r));
await browser.close();
console.log(`\n✔ ${outPath}`);
```

### 9.4 `scripts/build.mjs` — script + voix → `video.json`

```javascript
#!/usr/bin/env node
/* script.json + words.json (Whisper) -> video.json
 *   node scripts/build.mjs script.json words.json video.json
 *
 * script.json : { "title":"...", "logo":"assets/img/logo.png", "brandImage":"assets/img/brand_card.png",
 *                 "audio":"assets/voice.mp3", "duration": 71.9,
 *                 "scenes":[ {"image":"assets/img/s01.jpg",
 *                             "text":"pourquoi [[90|%]] des boutiques ... *étrangers* ?"}, ... ] }
 *   - *mot*            -> mot d'emphase (violet, ressort)
 *   - [[90|%]]         -> compteur 0 -> 90 affiché « 90 % » (emphase)   ·   [[120 000]] -> compteur sans suffixe
 * words.json  : [{ "word":"pourquoi", "start":0.30, "end":0.62 }, ...]   (sortie Whisper word_timestamps)
 *   Sans words.json : timings estimés (--wpm 165).
 */
import { readFileSync, writeFileSync } from "node:fs";
const [scriptPath, wordsPath, outPath] = process.argv.slice(2);
const wpmI = process.argv.indexOf("--wpm"); const WPM = wpmI > 0 ? +process.argv[wpmI + 1] : 165;
const script = JSON.parse(readFileSync(scriptPath, "utf8"));
const asr = wordsPath && wordsPath !== "-" ? JSON.parse(readFileSync(wordsPath, "utf8")) : null;

// 1) tokenisation du script (en conservant emphase / compteur)
const norm = s => s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]/g, "");
const toks = [];   // {w, em, count, scene}
script.scenes.forEach((sc, si) => {
  const re = /\[\[([^|\]]+)(?:\|([^\]]*))?\]\]|\*([^*]+)\*|(\S+)/g; let m;
  while ((m = re.exec(sc.text))) {
    if (m[1]) { const to = parseInt(m[1].replace(/\D/g, ""), 10), suf = m[2] ? "\u00A0" + m[2] : "";
      toks.push({ w: m[1] + suf, em: true, count: { from: 0, to, suffix: suf }, scene: si, n: [norm(m[1])] }); }
    else if (m[3]) m[3].split(/\s+/).forEach(x => toks.push({ w: x, em: true, scene: si, n: [norm(x)] }));
    else if (/^[?!:;»…]+$/.test(m[4]) && toks.length) toks[toks.length - 1].w += "\u00A0" + m[4];   // ponctuation isolée -> collée
    else toks.push({ w: m[4], em: false, scene: si, n: [norm(m[4])] });
  }
});

// 2) timings : alignement DP (Needleman-Wunsch) script <-> ASR ; sinon estimation
if (asr) {
  const A = toks.map(t => t.n[0]), B = asr.map(a => norm(a.word));
  const n = A.length, m = B.length, G = -1;
  const sc = (a, b) => a === b ? 2 : (a && b && (a.startsWith(b) || b.startsWith(a))) ? 1 : -2;
  const M = Array.from({ length: n + 1 }, () => new Float32Array(m + 1));
  for (let i = 1; i <= n; i++) M[i][0] = i * G; for (let j = 1; j <= m; j++) M[0][j] = j * G;
  for (let i = 1; i <= n; i++) for (let j = 1; j <= m; j++)
    M[i][j] = Math.max(M[i - 1][j - 1] + sc(A[i - 1], B[j - 1]), M[i - 1][j] + G, M[i][j - 1] + G);
  let i = n, j = m; const map = new Array(n).fill(-1);
  while (i > 0 && j > 0) {
    if (M[i][j] === M[i - 1][j - 1] + sc(A[i - 1], B[j - 1])) { if (sc(A[i - 1], B[j - 1]) > 0) map[i - 1] = j - 1; i--; j--; }
    else if (M[i][j] === M[i - 1][j] + G) i--; else j--;
  }
  // interpolation des mots non alignés
  let last = -1;
  for (let k = 0; k <= n; k++) if (k === n || map[k] >= 0) {
    const t1 = k === n ? asr[asr.length - 1].end : asr[map[k]].start, t0 = last < 0 ? asr[0].start : asr[map[last]].end;
    const gap = k - last - 1; for (let g = 1; g <= gap; g++) toks[last + g].t = lerp(t0, t1, g / (gap + 1));
    if (k < n) toks[k].t = asr[map[k]].start; last = k;
  }
} else {
  let t = 0.3; const per = 60 / WPM;
  toks.forEach(k => { k.t = t; t += per * (0.6 + Math.min(k.w.length, 10) / 10 * 0.8); });
}
function lerp(a, b, t) { return a + (b - a) * t; }

// 3) scènes : start = 1er mot - 0.13 s ; end = début de la scène suivante
const scenes = script.scenes.map((s, si) => {
  const ws = toks.filter(t => t.scene === si);
  return { start: Math.max(0.07, ws[0].t - 0.13), end: 0, image: s.image, pose: s.pose,
           words: ws.map(({ t, w, em, count }) => ({ t: +t.toFixed(3), w, ...(em ? { em: true } : {}), ...(count ? { count } : {}) })) };
});
const lastWord = toks[toks.length - 1].t;
scenes.forEach((s, i) => s.end = i < scenes.length - 1 ? scenes[i + 1].start : s.start + 99);
// écran final « marque »
const duration = script.duration || +(lastWord + 3.5).toFixed(2);
if (script.brandImage) {
  const bs = script.brand || {}; const bstart = bs.start ?? Math.min(duration - 3, lastWord + 0.6);
  scenes[scenes.length - 1].end = bstart;
  scenes.push({ type: "brand", start: bstart, end: duration, image: script.brandImage, words: bs.words || [] });
} else scenes[scenes.length - 1].end = duration;

writeFileSync(outPath, JSON.stringify({ title: script.title, fps: 30, duration, logo: script.logo, audio: script.audio || null, style: script.style, scenes }, null, 1));
console.log(`✔ ${outPath} — ${scenes.length} scènes, ${toks.length} mots, ${duration}s`);
```

### 9.5 `script.json` — exemple d'entrée

Syntaxe du texte : `*mot*` = mot-clé · `[[90|%]]` = compteur affiché « 90 % » · `[[120 000]]` = compteur sans suffixe · une ponctuation isolée (`?`, `!`, `:`) est collée au mot précédent avec une espace insécable.

```json
{ "title":"demo2", "logo":"assets/img/logo.png", "brandImage":"assets/img/brand_card.png", "duration": 16,
  "scenes":[
   {"image":"assets/img/s03.jpg","text":"tu savais qu'un vendeur *d'arachides* au congo pouvait gagner plus qu'un fonctionnaire ?"},
   {"image":"assets/img/s04.jpg","text":"un fonctionnaire gagne en moyenne [[120 000]] francs cfa par mois, alors que lui peut se faire [[12 000]] francs par jour. fais le *calcul.*"}
  ]}
```

### 9.6 `video.json` — format produit (extrait)

```json
{
  "duration": 14, "fps": 30, "logo": "assets/img/logo.png", "audio": "videos/001/voice.mp3",
  "style": { "--accent-a": "#7C3AED" },
  "scenes": [
    { "start": 0.07, "end": 4.6, "image": "assets/img/s01.jpg",
      "pose": { "rot0": -1.4, "rot1": 0.8 },
      "words": [ {"t":0.30,"w":"pourquoi"},
                 {"t":0.75,"w":"90 %","em":true,"count":{"from":0,"to":90,"suffix":" %"}} ] },
    { "type": "brand", "start": 9.2, "end": 14, "image": "assets/img/brand_card.png", "words": [] }
  ]
}
```
Le champ `style` écrase les tokens CSS (changer de marque sans toucher au HTML). `audio` est mixé par FFmpeg dans `render.mjs`.

---

## 10. Variantes de moteur

Le moteur natif ci-dessus est la voie recommandée (zéro dépendance de framework, rendu 100 % reproductible). Si tu préfères un autre outil, **garde les mêmes nombres** :

### 10.1 Remotion (React)

| Concept | Équivalent |
|---|---|
| `t` | `frame / fps` via `useCurrentFrame()` / `useVideoConfig()` |
| `outExpo`, `outCubic`… | `Easing.bezier(.16,1,.3,1)` dans `interpolate(..., {easing})` |
| images-clés du mot-clé (§4.6) | `interpolate(lt, [0,.03,.07,.10,.13,.20,.27,.30,.35,.43,.50,.60], [2.4,2.3,2.1,1.3,.62,.52,.85,1.1,1.2,1.05,.97,1])` |
| scène | `<Sequence from={Math.round(start*fps)} durationInFrames={Math.round((end-start)*fps)}>` |
| voix | `<Audio src={staticFile('voice.mp3')} />` |
| polices | `@remotion/google-fonts` ou `staticFile` local |

```tsx
// Squelette du mot (le reste = traduction directe de engine.js)
const Word: React.FC<{ t: number; em?: boolean; children: string }> = ({ t, em, children }) => {
  const { fps } = useVideoConfig(); const lt = useCurrentFrame() / fps - t;
  if (lt < 0) return <span style={{ opacity: 0 }}>{children}</span>;
  if (em) {
    const k = [0,.03,.07,.10,.13,.20,.27,.30,.35,.43,.50,.60];
    const s = interpolate(lt, k, [2.4,2.3,2.1,1.3,.62,.52,.85,1.1,1.2,1.05,.97,1], { extrapolateRight: 'clamp' });
    const o = interpolate(lt, [0,.03,.07,.10,.13], [0,.55,.6,.85,1], { extrapolateRight: 'clamp' });
    const b = interpolate(lt, [0,.03,.07,.10,.13], [12,8,6,2,0], { extrapolateRight: 'clamp' });
    return <span className="w em" style={{ opacity: o, filter: `blur(${b}px)`, transform: `scale(${s})` }}>{children}</span>;
  }
  const e = Easing.bezier(.215,.61,.355,1)(Math.min(1, lt / 0.2));
  return <span className="w" style={{ opacity: Math.min(1, e*2.4), filter: `blur(${4*(1-e)}px)`,
    transform: `translateY(${-14*(1-e)}px) rotate(${-3*(1-e)}deg)`, display: 'inline-block' }}>{children}</span>;
};
```

### 10.2 HyperFrames (HeyGen, HTML + GSAP)

HyperFrames décrit une composition en HTML avec attributs `data-*` et une timeline GSAP en pause enregistrée sur `window.__timelines`. Reprendre la même structure DOM/CSS que `engine/index.html`, déclarer la composition en 576×1024 / 30 fps / durée totale, puis traduire chaque animation du §4 en tweens GSAP avec les **mêmes** durées et courbes (`CustomEase`/`cubic-bezier` pour reproduire `outExpo` à l'identique ; les eases GSAP prédéfinies ne sont pas exactement les mêmes). Les mots et leur `data-start` viennent de `video.json`. Vérifier la syntaxe exacte dans la documentation de HyperFrames avant d'écrire la composition ; le moteur natif de ce fichier évite cette dépendance.

---

## 11. Contrôle qualité — points de contrôle

Rendre des stills (`--stills`) et vérifier :

| Instant (relatif à une scène `T`) | Attendu |
|---|---|
| `T−0,10` | carte et texte de la scène précédente flous et translucides |
| `T+0,05` | carte = bande plate, basse (≈ 100 px de haut, bas de carte vers y≈540) |
| `T+0,20` | carte à ≈ 70 % de sa hauteur, haut qui monte vite, aucun texte |
| `T+0,45` | carte à sa taille finale, légèrement tournée |
| `T+0,13 → T+0,35` | premiers mots qui tombent du dessus, grisés |
| mot-clé `+0,10` | énorme et flou ; `+0,20` : plus petit que la normale ; `+0,35` : plus gros que la normale ; `+0,60` : normal |
| écran final | logo d'en-tête absent, carte violette en rotation ≈ −2° puis ≈ 0,5°, barre pleine |
| première ligne de texte | sommet des ascendantes ≈ y 575 (576×1024) |

Checklist avant export : texte jamais coupé · pas plus de 4 lignes · aucun mot-clé en double consécutif · voix et mots alignés (test à l'oreille sur 3 points de la vidéo) · carte finale présente · barre à 100 % à la dernière image · durée = audio.

---

## 12. Pièges connus

| Problème | Cause | Solution |
|---|---|---|
| Police différente / texte qui bouge | Google Fonts non chargé pendant la capture | héberger Poppins 600 et 800 en local (`assets/fonts`) |
| Images « pop » en cours de rendu | image non décodée | `loadVideo` attend `decode()` ; ne pas retirer cette étape |
| Animation saccadée | `setTimeout`, CSS `transition/animation` | interdits : tout passe par `render(t)` |
| Mots qui sautent de ligne en comptant | largeur du compteur non figée | garder le calcul de largeur finale dans `load()` |
| Rendu lent | `--scale 1.875` + beaucoup de flous | normal ; paralléliser par vidéo ; `--scale 1` pour les tests |
| Voix décalée du texte | alignement Whisper imprécis sur les nombres | corriger à la main le `t` dans `video.json` (le seul fichier à retoucher) |
| Couleurs ternes | profil couleur | le lanceur force `--force-color-profile=srgb` |

---

## 13. Fiabilité des mesures et limites

- 🟢 **Mesuré** : dimensions, positions (carte, logo, barre, texte), tailles de police et interligne, durées de scène, séquence de transition, animation du mot et du mot-clé (image par image à 30 fps), compteurs, progression, écran final.
- 🟡 **Estimé** : angle et décalage exacts de chaque carte (le moteur utilise une alternance plausible), rayon des coins, forme précise de l'ombre, opacité du quadrillage, calibrage du zoom interne de l'image.
- ⚪ **Non analysé** : musique de fond et mixage audio, voix off (voix/TTS utilisé).
- Les transcriptions du §6.3 viennent d'images extraites à 1 image/s : elles peuvent contenir des mots manquants (« … »).
- Le moteur a été validé sur des images de test (placeholders) : remplacer par les vraies images, vraies polices Poppins 600/800 et vrai logo avant production.

---

*Kit complet (moteur, rendu, générateur, exemples) fourni dans `motion-kit.zip`.*
